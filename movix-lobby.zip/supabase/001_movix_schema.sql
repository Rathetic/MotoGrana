-- =====================================================================
-- MOVIX — Fase 3.1: estrutura do banco de dados (Supabase / PostgreSQL)
-- Cole este arquivo inteiro no SQL Editor do Supabase e clique em Run.
-- Requer PostgreSQL 15 ou superior (todo projeto novo do Supabase já tem).
-- É re-executável: usa "if not exists" e recria políticas/gatilhos.
--
-- COMO O LOCALSTORAGE ATUAL VIRA TABELAS
--   motograna:movimentacoes  -> movimentacoes
--   motograna:veiculos       -> veiculos
--   motograna:combustivel    -> abastecimentos
--   motograna:manutencoes    -> manutencoes
--   motograna:turnos         -> turnos
--   motograna:turnoAtual     -> turno_em_andamento
--   motograna:objetivos      -> objetivos
--   motograna:metaSemanal / metaMensal / veiculoAtivo -> configuracoes
--
-- DECISÕES DE PROJETO
--  1. Chave primária (user_id, id): o "id" continua sendo o texto que o
--     app já gera (ex.: "lq3x9k2ab1c"). Assim os vínculos antigos
--     (veiculoId, origem) migram SEM tabela de conversão, e reenviar o
--     mesmo registro apenas atualiza (upsert) em vez de duplicar.
--  2. Chaves estrangeiras compostas (user_id, ...): impossibilita que um
--     registro aponte para o veículo de OUTRO usuário.
--  3. user_id tem default auth.uid(): o app não precisa enviá-lo, e o RLS
--     rejeita qualquer tentativa de gravar em nome de outra pessoa.
--  4. created_at / updated_at / deleted_at em todas as tabelas de dados:
--     permitem sincronização incremental e propagar exclusões entre
--     aparelhos (exclusão lógica). Exclusão definitiva também é permitida.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 0. BASE: tipo de id e função de atualização automática de updated_at
-- ---------------------------------------------------------------------

-- Ids gerados pelo app: letras, números, "_" e "-", até 64 caracteres.
do $$
begin
  create domain public.id_cliente as text
    check (value ~ '^[A-Za-z0-9_-]{1,64}$');
exception when duplicate_object then null;
end $$;

create or replace function public.definir_atualizado_em()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;


-- ---------------------------------------------------------------------
-- 1. PLANOS (preparação para o Movix Premium — nada é bloqueado agora)
-- ---------------------------------------------------------------------
create table if not exists public.planos (
  codigo        text primary key,
  nome          text not null,
  max_veiculos  integer check (max_veiculos is null or max_veiculos > 0)  -- null = ilimitado
);

insert into public.planos (codigo, nome, max_veiculos) values
  ('free',    'Movix Free',    1),
  ('premium', 'Movix Premium', null)
on conflict (codigo) do nothing;


-- ---------------------------------------------------------------------
-- 2. PERFIS (1 por usuário; criado automaticamente no cadastro)
--    O usuário NÃO pode alterar o próprio plano (veja os GRANTs no fim).
-- ---------------------------------------------------------------------
create table if not exists public.perfis (
  user_id     uuid primary key references auth.users (id) on delete cascade,
  nome        text check (nome is null or char_length(nome) <= 80),
  plano       text not null default 'free' references public.planos (codigo),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);


-- ---------------------------------------------------------------------
-- 3. VEÍCULOS  (localStorage: motograna:veiculos)
--    tipo usa exatamente os rótulos do app. Para migrar: ano "" -> null,
--    placa "" -> null, apelido/marca/modelo truncados em 30 caracteres.
-- ---------------------------------------------------------------------
create table if not exists public.veiculos (
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id          public.id_cliente not null,
  tipo        text not null check (tipo in ('Motocicleta', 'Carro', 'Caminhão', 'Outro')),
  marca       text not null default '' check (char_length(marca)  <= 30),
  modelo      text not null default '' check (char_length(modelo) <= 30),
  ano         smallint check (ano is null or ano between 1950 and 2100),
  placa       text check (placa is null or (placa = upper(placa) and char_length(placa) between 1 and 8)),
  apelido     text not null check (char_length(btrim(apelido)) between 1 and 30),
  km_atual    numeric(10,1) not null default 0 check (km_atual >= 0),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  primary key (user_id, id)
);

-- Mesma placa não pode repetir entre veículos ativos do mesmo usuário.
create unique index if not exists veiculos_placa_unica
  on public.veiculos (user_id, placa) where placa is not null and deleted_at is null;
create index if not exists veiculos_sync on public.veiculos (user_id, updated_at);


-- ---------------------------------------------------------------------
-- 4. CONFIGURAÇÕES (1 por usuário)
--    metaSemanal, metaMensal e veiculoAtivo. Se o veículo ativo for
--    apagado de vez, apenas veiculo_ativo_id vira null (PostgreSQL 15+).
-- ---------------------------------------------------------------------
create table if not exists public.configuracoes (
  user_id           uuid primary key references auth.users (id) on delete cascade,
  meta_semanal      numeric(12,2) check (meta_semanal is null or meta_semanal > 0),
  meta_mensal       numeric(12,2) check (meta_mensal  is null or meta_mensal  > 0),
  veiculo_ativo_id  public.id_cliente,
  preferencias      jsonb not null default '{}'::jsonb check (jsonb_typeof(preferencias) = 'object'),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint configuracoes_veiculo_ativo_fk
    foreign key (user_id, veiculo_ativo_id)
    references public.veiculos (user_id, id)
    on delete set null (veiculo_ativo_id)
);


-- ---------------------------------------------------------------------
-- 5. ABASTECIMENTOS  (localStorage: motograna:combustivel)
--    distancia, litros e custo são CALCULADOS pelo banco com as mesmas
--    fórmulas do app (arredondando em 2 casas), então nunca ficam
--    inconsistentes. Ao migrar, envie apenas km_inicial, km_final,
--    consumo_km_l e preco_litro. (O custo recalculado pode diferir 1
--    centavo de um valor antigo por arredondamento.)
-- ---------------------------------------------------------------------
create table if not exists public.abastecimentos (
  user_id       uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id            public.id_cliente not null,
  veiculo_id    public.id_cliente not null,
  data          date not null,
  km_inicial    numeric(10,1) not null check (km_inicial >= 0),
  km_final      numeric(10,1) not null,
  consumo_km_l  numeric(6,2)  not null check (consumo_km_l > 0),
  preco_litro   numeric(8,3)  not null check (preco_litro > 0),
  distancia     numeric(10,1) generated always as (km_final - km_inicial) stored,
  litros        numeric(10,2) generated always as
                  (round((km_final - km_inicial) / consumo_km_l, 2)) stored,
  custo         numeric(12,2) generated always as
                  (round((km_final - km_inicial) / consumo_km_l * preco_litro, 2)) stored,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz,
  primary key (user_id, id),
  constraint abastecimentos_km_valido check (km_final > km_inicial),
  -- RESTRICT: não dá para apagar um veículo que ainda tem abastecimentos
  -- (é a mesma regra que o app já aplica hoje).
  constraint abastecimentos_veiculo_fk
    foreign key (user_id, veiculo_id) references public.veiculos (user_id, id) on delete restrict
);

create index if not exists abastecimentos_veiculo
  on public.abastecimentos (user_id, veiculo_id, data desc) where deleted_at is null;
create index if not exists abastecimentos_sync on public.abastecimentos (user_id, updated_at);


-- ---------------------------------------------------------------------
-- 6. MANUTENÇÕES  (localStorage: motograna:manutencoes)
--    "tipo" guarda o rótulo do app (Troca de óleo, Pneus, Kit relação,
--    Freios, Corrente, Outra...) sem lista fixa, para aceitar novos tipos.
--    Lembretes: prox_km (já calculado = km + intervalo) e/ou prox_data.
-- ---------------------------------------------------------------------
create table if not exists public.manutencoes (
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id          public.id_cliente not null,
  veiculo_id  public.id_cliente not null,
  tipo        text not null check (char_length(btrim(tipo)) between 1 and 40),
  descricao   text not null check (char_length(btrim(descricao)) between 1 and 60),
  valor       numeric(12,2) not null default 0 check (valor >= 0),
  km          numeric(10,1) not null check (km >= 0),
  data        date not null,
  prox_km     numeric(10,1),
  prox_data   date,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  primary key (user_id, id),
  constraint manutencoes_prox_km_valido check (prox_km is null or prox_km > km),
  constraint manutencoes_veiculo_fk
    foreign key (user_id, veiculo_id) references public.veiculos (user_id, id) on delete restrict
);

create index if not exists manutencoes_veiculo
  on public.manutencoes (user_id, veiculo_id, data desc) where deleted_at is null;
create index if not exists manutencoes_lembretes
  on public.manutencoes (user_id, prox_data) where prox_data is not null and deleted_at is null;
create index if not exists manutencoes_sync on public.manutencoes (user_id, updated_at);


-- ---------------------------------------------------------------------
-- 7. MOVIMENTAÇÕES FINANCEIRAS  (localStorage: motograna:movimentacoes)
--    O campo "origem" do app ({tipo, id}) vira duas colunas:
--      origem.tipo = "combustivel" -> abastecimento_id
--      origem.tipo = "manutencao"  -> manutencao_id
--    Regras de integridade:
--      * só despesas podem ter origem, e só UMA origem por linha;
--      * cada abastecimento/manutenção gera no máximo UMA despesa
--        (índices únicos abaixo) => sem lançamentos duplicados;
--      * apagar DEFINITIVAMENTE o abastecimento/manutenção apaga só a
--        despesa vinculada (CASCADE), igual ao comportamento do app.
--    categoria é texto livre (as categorias podem crescer no app).
-- ---------------------------------------------------------------------
create table if not exists public.movimentacoes (
  user_id           uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id                public.id_cliente not null,
  descricao         text not null check (char_length(btrim(descricao)) between 1 and 60),
  tipo              text not null check (tipo in ('ganho', 'despesa')),
  categoria         text not null check (char_length(btrim(categoria)) between 1 and 40),
  valor             numeric(12,2) not null check (valor > 0),
  data              date not null,
  abastecimento_id  public.id_cliente,
  manutencao_id     public.id_cliente,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz,
  primary key (user_id, id),
  constraint movimentacoes_uma_origem
    check (num_nonnulls(abastecimento_id, manutencao_id) <= 1),
  constraint movimentacoes_origem_so_despesa
    check (tipo = 'despesa' or num_nonnulls(abastecimento_id, manutencao_id) = 0),
  constraint movimentacoes_abastecimento_fk
    foreign key (user_id, abastecimento_id)
    references public.abastecimentos (user_id, id) on delete cascade,
  constraint movimentacoes_manutencao_fk
    foreign key (user_id, manutencao_id)
    references public.manutencoes (user_id, id) on delete cascade
);

create unique index if not exists movimentacoes_abastecimento_unica
  on public.movimentacoes (user_id, abastecimento_id)
  where abastecimento_id is not null and deleted_at is null;
create unique index if not exists movimentacoes_manutencao_unica
  on public.movimentacoes (user_id, manutencao_id)
  where manutencao_id is not null and deleted_at is null;
create index if not exists movimentacoes_data
  on public.movimentacoes (user_id, data desc) where deleted_at is null;
create index if not exists movimentacoes_categoria
  on public.movimentacoes (user_id, tipo, categoria, data desc) where deleted_at is null;
create index if not exists movimentacoes_sync on public.movimentacoes (user_id, updated_at);


-- ---------------------------------------------------------------------
-- 8. TURNOS REGISTRADOS  (localStorage: motograna:turnos)
--    "minutos" = duração efetiva (já descontadas as pausas), como no app.
--    registro: "automático" do app vira 'automatico' (sem acento).
--    veiculo_id é opcional (turnos antigos não têm veículo); fica pronto
--    para o desempenho por veículo do Premium.
-- ---------------------------------------------------------------------
create table if not exists public.turnos (
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id          public.id_cliente not null,
  data        date not null,
  inicio      time not null,
  fim         time not null,
  minutos     integer not null check (minutos between 1 and 1440),
  ganhos      numeric(12,2) not null default 0 check (ganhos >= 0),
  entregas    integer not null default 0 check (entregas >= 0),
  pausa_min   integer not null default 0 check (pausa_min >= 0),
  registro    text not null default 'manual' check (registro in ('automatico', 'manual')),
  km          numeric(10,1) check (km is null or km >= 0),
  veiculo_id  public.id_cliente,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  primary key (user_id, id),
  constraint turnos_veiculo_fk
    foreign key (user_id, veiculo_id)
    references public.veiculos (user_id, id)
    on delete set null (veiculo_id)
);

create index if not exists turnos_data
  on public.turnos (user_id, data desc) where deleted_at is null;
create index if not exists turnos_sync on public.turnos (user_id, updated_at);


-- ---------------------------------------------------------------------
-- 9. TURNO EM ANDAMENTO (localStorage: motograna:turnoAtual)
--    No máximo UM por usuário (chave primária = user_id), para o
--    cronômetro aparecer igual em todos os aparelhos.
--    pausas = [{"de": <ms>, "ate": <ms ou null>}, ...] (formato do app).
-- ---------------------------------------------------------------------
create table if not exists public.turno_em_andamento (
  user_id      uuid primary key default auth.uid() references auth.users (id) on delete cascade,
  iniciado_em  timestamptz not null,
  pausas       jsonb not null default '[]'::jsonb check (jsonb_typeof(pausas) = 'array'),
  veiculo_id   public.id_cliente,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint turno_andamento_veiculo_fk
    foreign key (user_id, veiculo_id)
    references public.veiculos (user_id, id)
    on delete set null (veiculo_id)
);


-- ---------------------------------------------------------------------
-- 10. OBJETIVOS / COFRINHO  (localStorage: motograna:objetivos)
--     Nota: "guardado" é o total atual. Se dois aparelhos alterarem o
--     mesmo objetivo ao mesmo tempo, vale a última gravação. Uma tabela
--     de depósitos/retiradas resolveria isso no futuro.
-- ---------------------------------------------------------------------
create table if not exists public.objetivos (
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id          public.id_cliente not null,
  nome        text not null check (char_length(btrim(nome)) between 1 and 40),
  meta        numeric(12,2) not null check (meta > 0),
  guardado    numeric(12,2) not null default 0 check (guardado >= 0),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  primary key (user_id, id)
);

create index if not exists objetivos_sync on public.objetivos (user_id, updated_at);


-- ---------------------------------------------------------------------
-- 11. MIGRAÇÕES (apoio à etapa 3.5)
--     Registra cada importação (LocalStorage ou backup JSON). O checksum
--     do conteúdo é único por usuário: o mesmo pacote não é importado
--     duas vezes. "status" permite retomar uma migração que falhou.
-- ---------------------------------------------------------------------
create table if not exists public.migracoes (
  user_id       uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id            uuid not null default gen_random_uuid(),
  fonte         text not null check (fonte in ('localstorage', 'backup_json')),
  checksum      text not null check (char_length(checksum) between 16 and 128),
  status        text not null default 'iniciada' check (status in ('iniciada', 'concluida', 'falhou')),
  resumo        jsonb not null default '{}'::jsonb check (jsonb_typeof(resumo) = 'object'),
  erro          text,
  created_at    timestamptz not null default now(),
  concluida_em  timestamptz,
  primary key (user_id, id),
  unique (user_id, checksum)
);


-- ---------------------------------------------------------------------
-- 12. GATILHOS: updated_at automático em todas as tabelas com esse campo
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'perfis', 'configuracoes', 'veiculos', 'abastecimentos', 'manutencoes',
    'movimentacoes', 'turnos', 'turno_em_andamento', 'objetivos'
  ] loop
    execute format('drop trigger if exists trg_%1$s_atualizado on public.%1$I', t);
    execute format(
      'create trigger trg_%1$s_atualizado before update on public.%1$I
         for each row execute function public.definir_atualizado_em()', t);
  end loop;
end $$;


-- ---------------------------------------------------------------------
-- 13. NOVO USUÁRIO: cria perfil e configurações automaticamente
--     (security definer: roda com permissão do dono, não do usuário).
--     O nome pode vir no cadastro: signUp({ options: { data: { nome } } }).
-- ---------------------------------------------------------------------
create or replace function public.criar_perfil_novo_usuario()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.perfis (user_id, nome)
  values (new.id, nullif(left(btrim(coalesce(new.raw_user_meta_data ->> 'nome', '')), 80), ''))
  on conflict (user_id) do nothing;

  insert into public.configuracoes (user_id) values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

revoke all on function public.criar_perfil_novo_usuario() from public, anon, authenticated;

drop trigger if exists trg_novo_usuario on auth.users;
create trigger trg_novo_usuario
  after insert on auth.users
  for each row execute function public.criar_perfil_novo_usuario();

-- Usuários que já existam no projeto antes deste script:
insert into public.perfis (user_id)        select id from auth.users on conflict (user_id) do nothing;
insert into public.configuracoes (user_id) select id from auth.users on conflict (user_id) do nothing;


-- ---------------------------------------------------------------------
-- 14. SEGURANÇA: ROW LEVEL SECURITY (RLS)
--     Cada usuário só enxerga e altera linhas com user_id = seu próprio
--     id. "(select auth.uid())" é a forma recomendada (avaliada uma vez
--     por consulta, mais rápida). Sem política = sem acesso.
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'configuracoes', 'veiculos', 'abastecimentos', 'manutencoes', 'movimentacoes',
    'turnos', 'turno_em_andamento', 'objetivos', 'migracoes'
  ] loop
    execute format('alter table public.%I enable row level security', t);

    execute format('drop policy if exists "%1$s_select" on public.%1$I', t);
    execute format('create policy "%1$s_select" on public.%1$I for select to authenticated
                      using (user_id = (select auth.uid()))', t);

    execute format('drop policy if exists "%1$s_insert" on public.%1$I', t);
    execute format('create policy "%1$s_insert" on public.%1$I for insert to authenticated
                      with check (user_id = (select auth.uid()))', t);

    execute format('drop policy if exists "%1$s_update" on public.%1$I', t);
    execute format('create policy "%1$s_update" on public.%1$I for update to authenticated
                      using (user_id = (select auth.uid()))
                      with check (user_id = (select auth.uid()))', t);

    execute format('drop policy if exists "%1$s_delete" on public.%1$I', t);
    execute format('create policy "%1$s_delete" on public.%1$I for delete to authenticated
                      using (user_id = (select auth.uid()))', t);
  end loop;
end $$;

-- Perfis: só leitura e edição do próprio perfil (criação/remoção são automáticas).
alter table public.perfis enable row level security;
drop policy if exists "perfis_select" on public.perfis;
create policy "perfis_select" on public.perfis for select to authenticated
  using (user_id = (select auth.uid()));
drop policy if exists "perfis_update" on public.perfis;
create policy "perfis_update" on public.perfis for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Planos: tabela de referência, somente leitura para usuários logados.
alter table public.planos enable row level security;
drop policy if exists "planos_select" on public.planos;
create policy "planos_select" on public.planos for select to authenticated using (true);


-- ---------------------------------------------------------------------
-- 15. PERMISSÕES (GRANT/REVOKE) — segunda camada de proteção
--     * visitantes sem login (anon): nenhum acesso;
--     * perfis: o usuário só pode alterar a coluna "nome". Assim ninguém
--       muda o próprio plano pelo navegador (isso será feito só pelo
--       servidor, com a chave service_role que NUNCA vai para o front).
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon;
alter default privileges in schema public revoke all on tables from anon;

revoke all on public.perfis from authenticated;
grant select on public.perfis to authenticated;
grant update (nome) on public.perfis to authenticated;

grant select on public.planos to authenticated;
grant select, insert, update, delete on
  public.configuracoes, public.veiculos, public.abastecimentos, public.manutencoes,
  public.movimentacoes, public.turnos, public.turno_em_andamento,
  public.objetivos, public.migracoes
to authenticated;


-- ---------------------------------------------------------------------
-- 16. VIEW DE APOIO: resumo diário (respeita o RLS de quem consulta)
-- ---------------------------------------------------------------------
create or replace view public.v_resumo_diario
with (security_invoker = true) as
select
  user_id,
  data,
  coalesce(sum(valor) filter (where tipo = 'ganho'),   0) as ganhos,
  coalesce(sum(valor) filter (where tipo = 'despesa'), 0) as despesas,
  coalesce(sum(valor) filter (where tipo = 'ganho'),   0)
    - coalesce(sum(valor) filter (where tipo = 'despesa'), 0) as lucro
from public.movimentacoes
where deleted_at is null
group by user_id, data;

revoke all on public.v_resumo_diario from anon;
grant select on public.v_resumo_diario to authenticated;


-- ---------------------------------------------------------------------
-- 17. FUTURO (NÃO ATIVO): limite de veículos por plano
--     A função abaixo lê o plano do usuário e bloqueia o cadastro além do
--     limite. O gatilho está comentado de propósito: hoje nada é
--     bloqueado. Para ativar no Premium, descomente o "create trigger".
-- ---------------------------------------------------------------------
create or replace function public.validar_limite_veiculos()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  limite  integer;
  atuais  integer;
begin
  select pl.max_veiculos into limite
    from public.perfis pe join public.planos pl on pl.codigo = pe.plano
   where pe.user_id = new.user_id;

  if limite is null then
    return new;  -- plano ilimitado (ou perfil sem plano definido)
  end if;

  select count(*) into atuais
    from public.veiculos
   where user_id = new.user_id and deleted_at is null;

  if atuais >= limite then
    raise exception 'Limite de veículos do plano atingido' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

revoke all on function public.validar_limite_veiculos() from public, anon, authenticated;

-- create trigger trg_limite_veiculos
--   before insert on public.veiculos
--   for each row execute function public.validar_limite_veiculos();


-- ---------------------------------------------------------------------
-- 18. OPCIONAL: atualização em tempo real entre aparelhos (Realtime)
--     Descomente para o app receber mudanças ao vivo. O RLS continua
--     valendo: cada usuário só recebe os próprios registros.
-- ---------------------------------------------------------------------
-- alter publication supabase_realtime add table
--   public.movimentacoes, public.veiculos, public.abastecimentos, public.manutencoes,
--   public.turnos, public.turno_em_andamento, public.objetivos, public.configuracoes;


-- ---------------------------------------------------------------------
-- 19. TESTE DE ISOLAMENTO (rode DEPOIS de criar 2 contas de teste)
--     Troque os dois UUIDs por ids reais (Authentication > Users).
--     Tudo dentro de uma transação que termina em ROLLBACK (não grava nada).
-- ---------------------------------------------------------------------
-- begin;
--   set local role authenticated;
--   select set_config('request.jwt.claims', '{"sub":"UUID-DO-USUARIO-A"}', true);
--   insert into public.veiculos (id, tipo, apelido) values ('teste1', 'Carro', 'Carro do A');
--   select count(*) as a_enxerga from public.veiculos;            -- esperado: 1
--
--   select set_config('request.jwt.claims', '{"sub":"UUID-DO-USUARIO-B"}', true);
--   select count(*) as b_enxerga from public.veiculos;            -- esperado: 0
--   insert into public.veiculos (user_id, id, tipo, apelido)
--     values ('UUID-DO-USUARIO-A', 'x', 'Carro', 'invasao');      -- esperado: ERRO de RLS
-- rollback;
